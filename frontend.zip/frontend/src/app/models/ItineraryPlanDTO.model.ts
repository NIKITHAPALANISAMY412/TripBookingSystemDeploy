export interface ItineraryPlanDTO {
  id?: number;
  packageId: number;
  dayNumber?: number;
  placeName?: string;
  placeDescription?: string;
  activities?: string;
}
