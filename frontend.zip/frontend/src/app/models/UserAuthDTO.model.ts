export interface UserAuthDto {
  userName?: string;
  userPassword?: string;
}
