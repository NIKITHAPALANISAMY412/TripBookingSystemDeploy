export interface UserRequestDTO {
  userName: string;
  userEmail: string;
  userPassword: string;
  roleIds: number[];
}
