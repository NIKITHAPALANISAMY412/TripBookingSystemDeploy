export interface WalletDTO {
  id?: number;
  userId: number;
  walletBalance: number;
  lastUpdated?: string;
}
