export interface RoleDTO {
  id?: number;
  roleName: string;
}
