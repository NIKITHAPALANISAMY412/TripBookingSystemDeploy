import { Component } from '@angular/core';

@Component({
  selector: 'app-get-bookings-by-status',
  imports: [],
  templateUrl: './get-bookings-by-status.html',
  styleUrl: './get-bookings-by-status.css',
})
export class GetBookingsByStatus {

}
