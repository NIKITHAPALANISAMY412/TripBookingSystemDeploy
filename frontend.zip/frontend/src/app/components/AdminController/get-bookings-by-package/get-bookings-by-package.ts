import { Component } from '@angular/core';

@Component({
  selector: 'app-get-bookings-by-package',
  imports: [],
  templateUrl: './get-bookings-by-package.html',
  styleUrl: './get-bookings-by-package.css',
})
export class GetBookingsByPackage {

}
