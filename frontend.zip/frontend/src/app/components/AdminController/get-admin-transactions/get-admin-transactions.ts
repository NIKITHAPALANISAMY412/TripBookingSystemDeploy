import { Component } from '@angular/core';

@Component({
  selector: 'app-get-admin-transactions',
  imports: [],
  templateUrl: './get-admin-transactions.html',
  styleUrl: './get-admin-transactions.css',
})
export class GetAdminTransactions {

}
