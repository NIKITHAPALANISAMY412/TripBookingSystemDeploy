import { Component } from '@angular/core';

@Component({
  selector: 'app-getadminwallet',
  imports: [],
  templateUrl: './getadminwallet.html',
  styleUrl: './getadminwallet.css',
})
export class Getadminwallet {

}
