import { Component } from '@angular/core';

@Component({
  selector: 'app-getallbooks',
  imports: [],
  templateUrl: './getallbooks.html',
  styleUrl: './getallbooks.css',
})
export class Getallbooks {

}
