import { Component } from '@angular/core';

@Component({
  selector: 'app-add-passenger',
  imports: [],
  templateUrl: './add-passenger.html',
  styleUrl: './add-passenger.css',
})
export class AddPassenger {

}
