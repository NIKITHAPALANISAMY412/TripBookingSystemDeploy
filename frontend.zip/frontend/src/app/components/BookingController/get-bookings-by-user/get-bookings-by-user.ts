import { Component } from '@angular/core';

@Component({
  selector: 'app-get-bookings-by-user',
  imports: [],
  templateUrl: './get-bookings-by-user.html',
  styleUrl: './get-bookings-by-user.css',
})
export class GetBookingsByUser {

}
