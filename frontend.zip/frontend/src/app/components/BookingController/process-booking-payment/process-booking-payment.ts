import { Component } from '@angular/core';

@Component({
  selector: 'app-process-booking-payment',
  imports: [],
  templateUrl: './process-booking-payment.html',
  styleUrl: './process-booking-payment.css',
})
export class ProcessBookingPayment {

}
