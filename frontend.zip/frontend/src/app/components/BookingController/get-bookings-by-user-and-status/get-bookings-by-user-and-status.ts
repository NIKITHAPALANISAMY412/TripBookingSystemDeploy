import { Component } from '@angular/core';

@Component({
  selector: 'app-get-bookings-by-user-and-status',
  imports: [],
  templateUrl: './get-bookings-by-user-and-status.html',
  styleUrl: './get-bookings-by-user-and-status.css',
})
export class GetBookingsByUserAndStatus {

}
