import { Component } from '@angular/core';

@Component({
  selector: 'app-footernav',
  imports: [],
  templateUrl: './footernav.html',
  styleUrl: './footernav.css',
})
export class Footernav {

}
