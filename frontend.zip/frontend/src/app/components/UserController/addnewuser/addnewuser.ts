import { Component } from '@angular/core';

@Component({
  selector: 'addnewuser',
  imports: [],
  templateUrl: './addnewuser.html',
  styleUrl: './addnewuser.css',
})
export class Addnewuser {

}
